/**
 * Import these functions to your own project to customize your build pipeline.
 * @author Joshua Heagle <joshuaheagle@gmail.com>
 * @module js-build-tools
 */
export { build } from './functions/build.mjs'
export { bundle } from './functions/bundle.mjs'
export { bundleMinify } from './functions/bundleMinify.mjs'
export { compileReadme as readme } from './functions/compileReadme.mjs'
export { copyFiles } from './functions/copyFiles.mjs'
export { copyFonts } from './functions/copyFonts.mjs'
export { defaultCmd } from './functions/default.mjs'
export { dist } from './functions/dist.mjs'
export { docs } from './functions/docs.mjs'
export { distMinify } from './functions/distMinify.mjs'
export * as gulpConfig from './gulp.config.mjs'
export { images } from './functions/images.mjs'
export { jsdocDocs } from './functions/jsdocDocs.mjs'
export { lint } from './functions/lint.mjs'
export * as partials from './functions/partials.mjs'
export { sass } from './functions/sass.mjs'
export { sourceLint } from './functions/sourceLint.mjs'
export { testFull } from './functions/testFull.mjs'
export * as testHelpers from './functions/testHelpers.mjs'
export { testQuick } from './functions/testQuick.mjs'
export { typeDocs } from './functions/typeDocs.mjs'
export { typeScript as typescript } from './functions/typeScript.mjs'
export { watchFull } from './functions/watchFull.mjs'
export { watchTest } from './functions/watchTest.mjs'
