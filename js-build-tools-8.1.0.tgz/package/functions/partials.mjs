/**
 * Micro-functions used as components for the main gulp functions.
 * @file
 * @author Joshua Heagle <joshuaheagle@gmail.com>
 * @version 3.0.0
 * @module partials
 * @memberOf module:js-build-tools
 */

export { addToReadme } from './partials/addToReadme.mjs'
export { beginWatcher } from './partials/beginWatcher.mjs'
export { cacheFiles } from './partials/cacheFiles.mjs'
export { clean } from './partials/clean.mjs'
export { copyFor } from './partials/copyFor.mjs'
export { distFor } from './partials/distFor.mjs'
export { distForSrc } from './partials/distForSrc.mjs'
export { distSeries } from './partials/distSeries.mjs'
export { imagesFor } from './partials/imagesFor.mjs'
export { importModule, importPeer, requirePeer } from './partials/loadPeer.mjs'
export { jsdocDocsFor } from './partials/jsdocDocsFor.mjs'
export { loadPlaywright, launchBrowser } from './partials/loadPlaywright.mjs'
export { lintSource } from './partials/lintSource.mjs'
export { minifyFor } from './partials/minifyFor.mjs'
export { neostandardLint } from './partials/neostandardLint.mjs'
export { readmeTemplate } from './partials/readmeTemplate.mjs'
export { removeDirectory } from './partials/removeDirectory.mjs'
export { resolveDocsMethod } from './partials/resolveDocsMethod.mjs'
export { runOnChange } from './partials/runOnChange.mjs'
export { sassFor } from './partials/sassFor.mjs'
export { serveStatic } from './partials/serveStatic.mjs'
export { tsFor } from './partials/tsFor.mjs'
export { typeDocsFor } from './partials/typeDocsFor.mjs'
